/* * This file is part of Maliit framework *
 *
 * Copyright (C) 2013 Openismus GmbH
 *
 * Contact: maliit-discuss@lists.maliit.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation
 * and appearing in the file LICENSE.LGPL included in the packaging
 * of this file.
 */

#include "abstractplatform.h"

namespace Maliit
{

AbstractPlatform::~AbstractPlatform()
{}

void AbstractPlatform::setApplicationWindow(QWindow *window, WId appWindowId)
{
    Q_UNUSED(window)
    Q_UNUSED(appWindowId)
}

} // namespace Maliit
